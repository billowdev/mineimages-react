import React from 'react';
import './App.css';
import 'bootstrap/dist/css/bootstrap.min.css';

import Address from  './componets/Address';
import Profile from './componets/Profile';
import Tabsbar from './componets/Tabsbar';


function App() {
  return (
    <div className="App">
        <Profile/>  
        <Address/>
        <Tabsbar/>
    </div>
  );
}

export default App;
