function TattooItme(props) {
    const {thumbnaiUrl} = props;
    return (
        <div className="TattooItme">
            <div className="TattooItme"></div>
            <img src={thumbnaiUrl}/>
        </div>
    );
}  


export default TattooItme;